from django.contrib import admin

from editor.models import *

admin.site.register(RichEditor)
